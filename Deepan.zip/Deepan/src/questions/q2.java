package questions;

import java.util.Scanner;

public class q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         int a=0,b=1,temp;
         System.out.println("Enter the Count:");
         Scanner  ii=new Scanner(System.in);
         int count=ii.nextInt();
         System.out.print(a+" "+b);
         for(int Start=0;Start<=count;Start++)

             { temp=a+b;
               System.out.print(" "+temp);
               a=b;
               b=temp;
	         }

	}

}
