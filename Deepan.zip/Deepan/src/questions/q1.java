package questions;


import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class q1 {
	public static void main(String q1[])
	{
		
      FIFO(); 
      System.out.println("************************");
      LIFO();
             
	}
		
	public static void LIFO() {
	Stack<String> s=new Stack<String>();
	s.push("A");
	s.push("b");
	s.push("c");
	System.out.println("Element in stack"+s);
	s.pop();
	System.out.println("Elemnet in after removing"+s);
	}
	public static void FIFO() {
	  Queue<Integer>queue=new LinkedList<>();
	  for(int i=0;i<5;i++)
         queue.add(i);
	     // System.out.println(queue);
         System.out.println( "Element in queue:"+queue);
         int rem=queue.remove();
         System.out.println("Remove Element:"+rem);
	
	}
}
