package questions;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
public class q7 {
   public static void main(String[] argv) {
      List<String>list1 = new ArrayList<String>();
      list1.add(0,"TestValue1");
      list1.add(1,"TestValue1");
      list1.add(2, "TestValue2");
      list1.add(3, "TestValue1");
      list1.add(4, "TestValue2");
      list1.add(5, "TestValue2");
      
      HashSet<String>set = new HashSet<String>(list1);
      List<String>list2 = new ArrayList<String>(set);
      System.out.println("List after removing duplicate elements:");
      for (Object ob: list2)
         System.out.println(ob);
   }
}
