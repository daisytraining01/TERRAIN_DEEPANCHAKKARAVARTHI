package questions;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class q3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int ln=0;
try {
	BufferedReader in=new BufferedReader(new FileReader("txt.txt"));
	String line=null;
	
	while((line=in.readLine())!=null) {
		ln++;
		if(ln%2!=0) {
		System.out.println("Line"+ln+":"+line);
	       }
		}
 }catch(IOException e)
   {
	e.printStackTrace();}
	}

}
