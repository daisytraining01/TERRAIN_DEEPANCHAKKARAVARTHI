package questions;

public class q5 {
static String strr;
	public static void main(String[] s) {
		// TODO Auto-generated method stub
		String str="REST ASSURED";
		String rstr,Srstr;
		rstr = str.replaceAll("S", "");
		Srstr=rstr.replaceAll("T", "") ;
		
		System.out.println(Srstr);
		}
	
}
